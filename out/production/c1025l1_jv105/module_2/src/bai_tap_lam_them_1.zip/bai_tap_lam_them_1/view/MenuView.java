package module_2.src.bai_tap_lam_them_1.view;

import module_2.src.bai_tap_lam_them_1.controller.VehicleController;
import module_2.src.bai_tap_lam_them_1.util.ConstantsVariables;

import java.util.Scanner;

public class MenuView {
    private VehicleController controller;
    private static final VehicleAddView vehicleAddView = new VehicleAddView();
    private static final VehicleDisplayView vehicleDisplayView = new VehicleDisplayView();
    private static final VehicleDeletedView vehicleDeletedView = new VehicleDeletedView();
    private static final VehicleFoundView vehicleFoundView = new VehicleFoundView();

    public MenuView(VehicleController controller) {
        this.controller = controller;
    }

    public void start() {
        boolean flag = true;
        Scanner scanner = new Scanner(System.in);
        byte choice = 0;
        while (flag) {
            System.out.println("" +
                    "1. Add a new vehicle \n" +
                    "2. Display vehicle\n" +
                    "3. Delete vehicle\n" +
                    "4. Find by the license plate\n" +
                    "5. Exit ");
            choice = Byte.parseByte(scanner.nextLine());
            createMenu(choice);
            if (choice == ConstantsVariables.EXIT) {
                flag = false;
            }
        }
    }

    private static void createMenu(byte choice) {
        switch (choice) {
            case 1:
                System.out.println("Add a new vehicle");
                vehicleAddView.displayAddMenu(
                        "1. Add a truck \n" +
                                "2. Add a car \n" +
                                "3. Add a bike \n" +
                                "4. Back the main menu \n");
                break;
            case 2:
                System.out.println("Display vehicle");
                vehicleDisplayView.displayViewMenu(
                        "1. Display truck \n" +
                                "2. Display car \n" +
                                "3. Display bike \n" +
                                "4. Back the main menu \n");
                break;
            case 3:
                System.out.println("Delete vehicle");
                vehicleDeletedView.displayDeletedView();
                break;
            case 4:
                System.out.println("Find by license plate");
                vehicleFoundView.displayFoundVehicleView();
                break;
            case 5:
                System.out.println("Exit");
                break;
            default:
                System.out.println("No choice");
        }
    }

}
