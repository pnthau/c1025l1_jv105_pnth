package module_2.src.bai_tap_lam_them_1.view;

import module_2.src.bai_tap_lam_them_1.until.ConstantsVariables;

import java.util.Scanner;

public class RunApp {
    public static void main(String[] args) {
        boolean flag = true;
        Scanner scanner = new Scanner(System.in);
        byte choice = 0;
        while (flag) {
            System.out.println("" +
                    "1. Add a new vehicle \n" +
                    "2. Display vehicle\n" +
                    "3. Delete vehicle\n" +
                    "4. Find by the license plate\n" +
                    "5. Exit ");
            choice = Byte.parseByte(scanner.nextLine());
            createMenu(choice);
            if (choice == ConstantsVariables.EXIT) {
                flag = false;
            }
        }
    }

    private static void createMenu(byte choice) {

        switch (choice) {
            case 1:
                System.out.println("Add a new vehicle");
                VehicleAddView.displayAddMenu(
                        "1. Add a truck \n" +
                                "2. Add a car \n" +
                                "3. Add a bike \n" +
                                "4. Back the main menu \n");
                break;
            case 2:
                System.out.println("Display vehicle");
                //VehicleAddView.displayMenu();
                break;
            case 3:
                System.out.println("Delete vehicle");
                break;
            case 4:
                System.out.println("Find by license plate");
                break;
            case 5:
                System.out.println("Exit");
                break;
            default:
                System.out.println("No choice");
        }
    }
}
