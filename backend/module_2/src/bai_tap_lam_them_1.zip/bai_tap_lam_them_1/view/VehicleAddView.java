package module_2.src.bai_tap_lam_them_1.view;

import module_2.src.bai_tap_lam_them_1.until.ConstantsVariables;
import module_2.src.bai_tap_lam_them_1.until.Menu;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class VehicleAddView {
//    public static void displayAddMenu() {
//        Menu.displayAddMenu(
//                "1. Add a truck \n" +
//                        "2. Add a car \n" +
//                        "3. Add a bike \n");
//    }

    public static void displayAddMenu(String announceContent) {
        boolean flag = true;
        Scanner scanner = new Scanner(System.in);
        byte choice = 0;
        while (flag) {
            System.out.println(announceContent);
            choice = Byte.parseByte(scanner.nextLine());
            createMenu(choice, announceContent);
            if (choice == ConstantsVariables.RETURN) {
                flag = false;
            }
        }
    }

    private static void createMenu(byte choice, String announceContent) {
        String[] optionContents = announceContent.split("\n");
        switch (choice) {
            case 1:
                System.out.println(Menu.getOptionMenu(optionContents[0]));

                break;
            case 2:
                System.out.println(Menu.getOptionMenu(optionContents[1]));
                break;
            case 3:
                System.out.println(Menu.getOptionMenu(optionContents[2]));
                break;
            case 4:
                System.out.println(Menu.getOptionMenu(optionContents[3]));
                break;
            default:
                System.out.println("No choice");
        }
    }


}
