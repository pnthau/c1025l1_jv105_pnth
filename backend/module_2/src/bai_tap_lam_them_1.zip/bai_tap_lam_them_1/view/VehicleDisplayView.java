package module_2.src.bai_tap_lam_them_1.view;

import module_2.src.bai_tap_lam_them_1.until.Menu;

public class VehicleDisplayView {
//    public static void displayMenu() {
//        Menu.displayAddMenu(
//                "1. Display truck \n" +
//                        "2. Display car \n" +
//                        "3. Display bike \n");
//    }


}
