package module_2.src.bai_tap_lam_them_1.until;

public final class ConstantsVariables {
    public static final String SPACE_CHAR = " - ";
    public static final int NOT_FOUND = -1;
    public static byte RETURN = 4;
    public static byte EXIT = 5;

    private ConstantsVariables() {

    }
}
