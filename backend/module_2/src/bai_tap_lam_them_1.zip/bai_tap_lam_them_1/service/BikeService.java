package module_2.src.bai_tap_lam_them_1.service;

import module_2.src.bai_tap_lam_them_1.entity.Bike;
import module_2.src.bai_tap_lam_them_1.entity.Vehicle;
import module_2.src.bai_tap_lam_them_1.until.ConstantsVariables;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BikeService implements IBikeService {
    private final List<Bike> bikeList;


    public BikeService() {
        bikeList = new ArrayList<>();
    }

    public BikeService(List<Bike> bikeList) {
        this.bikeList = bikeList;
    }


    @Override
    public List<Bike> getAll() {
        return Collections.unmodifiableList(this.bikeList);
    }

    @Override
    public boolean add(Bike bike) {
        this.bikeList.add(bike);
        return true;
    }

    @Override
    public boolean delete(String licensePlate) {
        int index = findIndexByLicensePlate(licensePlate);
        if (index == ConstantsVariables.NOT_FOUND) {
            return false;
        }

        this.bikeList.remove(index);
        return true;
    }

    private int findIndexByLicensePlate(String licensePlate) {
        for (int index = 0; index < this.bikeList.size(); index++) {
            if (this.bikeList.get(index).getLicensePlate().equals(licensePlate)) {
                return index;
            }
        }
        return ConstantsVariables.NOT_FOUND;
    }

    @Override
    public List<Bike> findVehicleByLicensePlate(String licensePlate) {
        List<Bike> foundList = new ArrayList<>();

        for (Bike bike : this.bikeList) {
            if (bike.getLicensePlate().equals(licensePlate)) {
                foundList.add(bike);
            }
        }
        return foundList;
    }
}
