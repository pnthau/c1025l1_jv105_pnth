package module_2.src.bai_tap_lam_them_1.service;

import module_2.src.bai_tap_lam_them_1.entity.Truck;

public interface ITruckService extends IService<Truck, String> {
}
