package module_2.src.bai_tap_lam_them_1.service;

import module_2.src.bai_tap_lam_them_1.entity.Bike;
import module_2.src.bai_tap_lam_them_1.entity.Truck;
import module_2.src.bai_tap_lam_them_1.entity.Vehicle;
import module_2.src.bai_tap_lam_them_1.until.ConstantsVariables;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class TruckService implements ITruckService {
    List<Truck> truckList;

    public TruckService() {
        truckList = new ArrayList<>();
    }

    public TruckService(List<Truck> truckList) {
        this.truckList = truckList;
    }

    @Override
    public List<Truck> getAll() {
        return Collections.unmodifiableList(this.truckList);
    }

    @Override
    public boolean add(Truck truck) {
        return false;
    }

    @Override
    public boolean delete(String licensePlate) {
        int index = findIndexByLicensePlate(licensePlate);
        if (index == ConstantsVariables.NOT_FOUND) {
            return false;
        }

        this.truckList.remove(index);
        return true;
    }

    private int findIndexByLicensePlate(String licensePlate) {
        for (int index = 0; index < this.truckList.size(); index++) {
            if (this.truckList.get(index).getLicensePlate().equals(licensePlate)) {
                return index;
            }
        }
        return ConstantsVariables.NOT_FOUND;
    }

    public List<Truck> findVehicleByLicensePlate(String licensePlate) {
        List<Truck> foundList = new ArrayList<>();

        for (Truck truck : this.truckList) {
            if (truck.getLicensePlate().equals(licensePlate)) {
                foundList.add(truck);
            }
        }
        return foundList;
    }
}
