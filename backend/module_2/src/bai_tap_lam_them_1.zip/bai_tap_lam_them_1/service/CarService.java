package module_2.src.bai_tap_lam_them_1.service;

import module_2.src.bai_tap_lam_them_1.entity.Car;
import module_2.src.bai_tap_lam_them_1.entity.Truck;
import module_2.src.bai_tap_lam_them_1.entity.Vehicle;
import module_2.src.bai_tap_lam_them_1.until.ConstantsVariables;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class CarService implements ICarService {
    private final List<Car> carList;


    public CarService() {
        carList = new ArrayList<>();
    }

    public CarService(List<Car> carList) {
        this.carList = carList;
    }


    @Override
    public List<Car> getAll() {
        return Collections.unmodifiableList(this.carList);
    }

    @Override
    public boolean add(Car car) {
        this.carList.add(car);
        return true;
    }

    @Override
    public boolean delete(String licensePlate) {
        int index = findIndexByLicensePlate(licensePlate);
        if (index == ConstantsVariables.NOT_FOUND) {
            return false;
        }

        this.carList.remove(index);
        return true;
    }

    @Override
    public List<Car> findVehicleByLicensePlate(String licensePlate) {
        List<Car> foundList = new ArrayList<>();

        for (Car car : this.carList) {
            if (car.getLicensePlate().equals(licensePlate)) {
                foundList.add(car);
            }
        }
        return foundList;
    }

    private int findIndexByLicensePlate(String licensePlate) {
        for (int index = 0; index < this.carList.size(); index++) {
            if (this.carList.get(index).getLicensePlate().equals(licensePlate)) {
                return index;
            }
        }
        return ConstantsVariables.NOT_FOUND;
    }

//    public List<Vehicle> findVehicleByLicensePlate(String licensePlate) {
//
//    }
}
