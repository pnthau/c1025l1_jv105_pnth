package module_2.src.bai_tap_lam_them_1.controller;

import module_2.src.bai_tap_lam_them_1.entity.Bike;
import module_2.src.bai_tap_lam_them_1.entity.Vehicle;
import module_2.src.bai_tap_lam_them_1.service.BikeService;
import module_2.src.bai_tap_lam_them_1.service.IService;

import java.util.List;

public class BikeController {
    private IService<Bike, String> service;

    public BikeController() {
    }

    public BikeController(IService<Bike, String> service) {
        this.service = service;
    }

    public void display() {
        for (Bike bike : service.getAll()) {
            System.out.println(bike.toString());
        }
    }

    public boolean add(Bike bike) {
        return this.service.add(bike);
    }

    public boolean delete(String licensePlate) {
        return this.service.delete(licensePlate);
    }

    public List<Bike> findVehicleByLicensePlate(String licensePlate) {
        return this.service.findVehicleByLicensePlate(licensePlate);
    }
}
