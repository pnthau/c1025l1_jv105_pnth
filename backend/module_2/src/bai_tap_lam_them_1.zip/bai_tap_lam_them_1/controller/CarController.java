package module_2.src.bai_tap_lam_them_1.controller;

import module_2.src.bai_tap_lam_them_1.entity.Car;
import module_2.src.bai_tap_lam_them_1.service.IService;

import java.util.List;

public class CarController {
    private IService<Car, String> service;

    public CarController() {
    }

    public CarController(IService<Car, String> service) {
        this.service = service;
    }

    public void display() {
        for (Car Car : service.getAll()) {
            System.out.println(Car.toString());
        }
    }

    public boolean add(Car Car) {
        return this.service.add(Car);
    }

    public boolean delete(String licensePlate) {
        return this.service.delete(licensePlate);
    }

    public List<Car> findVehicleByLicensePlate(String licensePlate) {
        return this.service.findVehicleByLicensePlate(licensePlate);
    }
}
