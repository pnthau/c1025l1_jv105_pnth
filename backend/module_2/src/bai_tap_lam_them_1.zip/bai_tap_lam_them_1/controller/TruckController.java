package module_2.src.bai_tap_lam_them_1.controller;

import module_2.src.bai_tap_lam_them_1.entity.Bike;
import module_2.src.bai_tap_lam_them_1.entity.Truck;
import module_2.src.bai_tap_lam_them_1.entity.Vehicle;
import module_2.src.bai_tap_lam_them_1.service.IService;

import java.util.List;

public class TruckController {
    private IService<Truck, String> service;

    public TruckController() {
    }

    public TruckController(IService<Truck, String> service) {
        this.service = service;
    }

    public void display() {
        for (Truck truck : service.getAll()) {
            System.out.println(truck.toString());
        }
    }

    public boolean add(Truck truck) {
        return this.service.add(truck);
    }

    public boolean delete(String licensePlate) {
        return this.service.delete(licensePlate);
    }

    public List<Truck> findVehicleByLicensePlate(String licensePlate) {
        return this.service.findVehicleByLicensePlate(licensePlate);
    }
}
